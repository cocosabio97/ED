/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 * Indica el nombre y apellidos de los componentes del
 * grupo:
 *
 * Nombre 1:
 * Nombre 2:
 * ---------------------------------------------------
 */



#include <iostream>
#include <vector>
#include <fstream>
#include <cassert>

class Date {
public:  
  Date();
  Date(int day, int month, int year);
  
  bool operator<(const Date &other) const;
  bool operator<=(const Date &other) const;
  
  void read(std::istream &in);
  
private:
  // ...
};

std::istream & operator>>(std::istream &in, Date &f) {
  f.read(in);
  return in;
}


class FamilyTree {
public:
  FamilyTree();
  ~FamilyTree();
  void read(std::istream &in);
  bool nonsense();

private:
  struct FamilyTreeNode {
    Date date;
    std::vector<FamilyTreeNode *> children;  
  };

  FamilyTreeNode *root;
};

std::istream & operator>>(std::istream &in, FamilyTree &f) {
  f.read(in);
  return in;
}


using namespace std;

void tratar_caso() {
  // ...
}


int main() {
#ifndef DOMJUDGE
  std::ifstream in("sample.in");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

  int num_casos;
  cin >> num_casos;
  for (int i = 0; i < num_casos; i++) {
    tratar_caso();
  }

#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
  // Descomentar si se trabaja en Windows
  // system("PAUSE");
#endif

  return 0;
}
