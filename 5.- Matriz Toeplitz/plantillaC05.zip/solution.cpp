/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 * Indica el nombre y apellidos de los componentes del
 * grupo:
 *
 * Nombre 1:
 * Nombre 2:
 * ---------------------------------------------------
 */

#include <iostream>
#include <fstream>
#include <list>


using namespace std;


bool es_toeplitz(const list<list<int>> &matriz) {
  // ... Implementar ...
  return false;
}


bool tratar_caso() {
  // ... Implementar ...
  return false;
}

int main() {
#ifndef DOMJUDGE
  std::ifstream in("sample.in");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

  while (tratar_caso()) { }

#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
  // Descomentar si se trabaja en Windows
  // system("PAUSE");
#endif

  return 0;
}